from django.apps import AppConfig


class SnapinsightConfig(AppConfig):
    name = 'snapinsight'
